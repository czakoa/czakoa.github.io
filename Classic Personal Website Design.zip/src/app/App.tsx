import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";
import { AbstractArches } from "./components/AbstractArches";

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll();
  
  const headerOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const gridScale = useTransform(scrollYProgress, [0, 0.3], [1, 0.98]);

  return (
    <div ref={containerRef} className="min-h-screen bg-background">
      {/* Abstract arches with lighting */}
      <AbstractArches />
      
      {/* Subtle texture overlay */}
      <div className="fixed inset-0 opacity-[0.015] pointer-events-none bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZmlsdGVyIGlkPSJub2lzZSI+PGZlVHVyYnVsZW5jZSB0eXBlPSJmcmFjdGFsTm9pc2UiIGJhc2VGcmVxdWVuY3k9IjAuOSIgbnVtT2N0YXZlcz0iNCIvPjwvZmlsdGVyPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbHRlcj0idXJsKCNub2lzZSkiLz48L3N2Zz4=')]" />

      {/* Header with animated fade */}
      <motion.header 
        style={{ opacity: headerOpacity }}
        className="fixed top-0 left-0 right-0 z-50 px-8 py-6 flex justify-between items-start"
      >
        <div className="flex items-baseline gap-3">
          <div className="text-[0.65rem] tracking-[0.3em] uppercase text-foreground/40">Your Name</div>
          <div className="w-px h-4 bg-foreground/20" />
          <div className="text-[0.65rem] tracking-[0.2em] uppercase text-foreground/30">Portfolio</div>
        </div>
      </motion.header>

      {/* Main Content */}
      <motion.div 
        style={{ scale: gridScale }}
        className="relative"
      >
        {/* Hero Grid Layout */}
        <div className="min-h-screen grid grid-cols-12 gap-px bg-border">
          {/* Left decorative column */}
          <div className="col-span-1 bg-background" />

          {/* Main content area */}
          <div className="col-span-10 bg-background">
            <div className="min-h-screen flex flex-col justify-center px-12 py-24">
              {/* Masthead */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="mb-16"
              >
                <div className="border-t border-b border-foreground/10 py-8">
                  <h1 
                    className="tracking-tight leading-[0.9]"
                    style={{ fontSize: 'clamp(4rem, 12vw, 9rem)' }}
                  >
                    Your Name
                  </h1>
                </div>
              </motion.div>

              {/* Three column layout - newspaper style */}
              <div className="grid grid-cols-3 gap-12">
                {/* Column 1 - Tagline */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.4 }}
                  className="space-y-4"
                >
                  <div className="h-px bg-foreground/20 mb-6" />
                  <p className="text-[0.7rem] tracking-[0.25em] uppercase text-foreground/50 mb-4">
                    Designer & Developer
                  </p>
                  <p className="text-[0.95rem] leading-relaxed text-foreground/70">
                    Based in [City]. Working at the intersection of craft and technology.
                  </p>
                </motion.div>

                {/* Column 2 - Main copy */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.5 }}
                  className="space-y-6"
                >
                  <div className="h-px bg-foreground/20 mb-6" />
                  <p className="text-[1.05rem] leading-[1.7] text-foreground/80">
                    I believe in work that speaks quietly but carries weight. Every pixel, 
                    every interaction is a deliberate choice.
                  </p>
                  <p className="text-[1.05rem] leading-[1.7] text-foreground/80">
                    Currently exploring the tension between restraint and expression.
                  </p>
                </motion.div>

                {/* Column 3 - Contact */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.6 }}
                  className="space-y-6"
                >
                  <div className="h-px bg-foreground/20 mb-6" />
                  <div className="space-y-3">
                    <a 
                      href="mailto:your@email.com"
                      className="group block text-[0.85rem] tracking-wide text-foreground/60 hover:text-[#ff3366] transition-colors"
                    >
                      <span className="inline-block group-hover:translate-x-1 transition-transform">
                        Email →
                      </span>
                    </a>
                    <a 
                      href="#"
                      className="group block text-[0.85rem] tracking-wide text-foreground/60 hover:text-[#ff3366] transition-colors"
                    >
                      <span className="inline-block group-hover:translate-x-1 transition-transform">
                        LinkedIn →
                      </span>
                    </a>
                    <a 
                      href="#"
                      className="group block text-[0.85rem] tracking-wide text-foreground/60 hover:text-[#ff3366] transition-colors"
                    >
                      <span className="inline-block group-hover:translate-x-1 transition-transform">
                        Twitter →
                      </span>
                    </a>
                  </div>

                  {/* Neon accent */}
                  <div className="pt-8">
                    <a
                      href="#work"
                      className="group relative inline-block"
                    >
                      <div className="absolute inset-0 bg-[#ff3366] blur-lg opacity-0 group-hover:opacity-20 transition-opacity duration-500" />
                      <div className="relative border border-[#ff3366] px-6 py-3 text-[0.7rem] tracking-[0.25em] uppercase text-[#ff3366] hover:bg-[#ff3366] hover:text-background transition-all duration-300">
                        View Work
                      </div>
                    </a>
                  </div>
                </motion.div>
              </div>

              {/* Scroll indicator */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1, delay: 1 }}
                className="mt-24 flex items-center gap-4"
              >
                <div className="text-[0.65rem] tracking-[0.3em] uppercase text-foreground/30">
                  Scroll to explore
                </div>
                <motion.div
                  animate={{ x: [0, 10, 0] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  className="text-foreground/30"
                >
                  ↓
                </motion.div>
              </motion.div>
            </div>
          </div>

          {/* Right decorative column */}
          <div className="col-span-1 bg-background relative" />
        </div>

        {/* Featured Visual - Below the fold */}
        <div className="grid grid-cols-12 gap-px bg-border">
          <div className="col-span-1 bg-background" />
          
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            className="col-span-10 bg-background py-24 px-12"
          >
            {/* Section label */}
            <div className="flex items-center gap-8 mb-12">
              <div className="text-[0.65rem] tracking-[0.3em] uppercase text-foreground/40">
                Featured
              </div>
              <div className="h-px flex-1 bg-foreground/10" />
              <div className="text-[0.65rem] tracking-[0.2em] text-foreground/30">
                01
              </div>
            </div>

            {/* Large featured image/video placeholder */}
            <div className="relative group">
              <motion.div
                whileHover={{ scale: 0.995 }}
                transition={{ duration: 0.6, ease: "easeOut" }}
                className="relative aspect-[16/10] overflow-hidden bg-gradient-to-br from-[#e6dcc9] via-[#d4c9b5] to-[#8b7e6b] flex items-center justify-center"
              >
                {/* Placeholder for your image or video */}
                <div className="text-center space-y-4">
                  <div className="text-[0.7rem] tracking-[0.3em] uppercase text-foreground/30">
                    Featured Work
                  </div>
                  <div className="text-[0.85rem] text-foreground/20 tracking-wide">
                    Replace with your image or video
                  </div>
                </div>
                
                {/* Overlay info */}
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  <div className="absolute bottom-12 left-12 right-12">
                    <p className="text-[0.7rem] tracking-[0.25em] uppercase text-card mb-2">
                      Project Title
                    </p>
                    <p className="text-[1.1rem] text-card/90 max-w-md">
                      A brief description of the work and what it represents.
                    </p>
                  </div>
                </div>
              </motion.div>

              {/* Caption */}
              <div className="mt-6 flex items-start justify-between text-[0.75rem] text-foreground/50">
                <div className="tracking-wide">
                  Project Name — 2025
                </div>
                <div className="tracking-[0.2em] uppercase">
                  Design & Development
                </div>
              </div>
            </div>
          </motion.div>

          <div className="col-span-1 bg-background" />
        </div>

        {/* Footer */}
        <div className="grid grid-cols-12 gap-px bg-border">
          <div className="col-span-1 bg-background" />
          
          <div className="col-span-10 bg-background px-12 py-16">
            <div className="border-t border-foreground/10 pt-8 flex justify-between items-center">
              <div className="text-[0.65rem] tracking-[0.3em] uppercase text-foreground/30">
                © 2025 Your Name
              </div>
              <div className="flex gap-8">
                <a href="#" className="text-[0.65rem] tracking-[0.2em] uppercase text-foreground/30 hover:text-foreground/60 transition-colors">
                  Instagram
                </a>
                <a href="#" className="text-[0.65rem] tracking-[0.2em] uppercase text-foreground/30 hover:text-foreground/60 transition-colors">
                  Dribbble
                </a>
                <a href="#" className="text-[0.65rem] tracking-[0.2em] uppercase text-foreground/30 hover:text-foreground/60 transition-colors">
                  GitHub
                </a>
              </div>
            </div>
          </div>

          <div className="col-span-1 bg-background" />
        </div>
      </motion.div>
    </div>
  );
}